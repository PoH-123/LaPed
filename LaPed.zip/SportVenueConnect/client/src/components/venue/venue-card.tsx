import { 
  MapPin, 
  Star, 
  Wifi, 
  Car, 
  Utensils,
  Clock
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

interface VenueCardProps {
  title: string;
  location: string;
  price: string;
  rating: number;
  reviews: number;
  image: string;
  type: string;
  features?: string[];
  distance?: string;
}

export function VenueCard({ 
  title, 
  location, 
  price, 
  rating, 
  reviews, 
  image,
  type,
  features = ["wifi", "parking"],
  distance = "1.2 km"
}: VenueCardProps) {
  return (
    <Card className="group overflow-hidden border-none shadow-md hover:shadow-xl transition-all duration-300 bg-white dark:bg-slate-900">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3">
          <Badge className="bg-white/90 text-slate-900 hover:bg-white font-semibold backdrop-blur-sm shadow-sm">
            {type}
          </Badge>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <div className="flex items-center text-white text-sm font-medium">
            <MapPin className="w-3 h-3 mr-1 text-primary" />
            {distance} dari lokasi anda
          </div>
        </div>
      </div>

      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-heading font-bold text-lg leading-tight group-hover:text-primary transition-colors">
            {title}
          </h3>
          <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-md border border-yellow-100">
            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500 mr-1" />
            <span className="text-xs font-bold text-yellow-700">{rating}</span>
          </div>
        </div>
        <p className="text-muted-foreground text-sm line-clamp-1 flex items-center">
          {location}
        </p>
      </CardHeader>

      <CardContent className="p-4 pt-2">
        <div className="flex gap-3 mb-4">
          {features.includes("wifi") && (
            <div className="flex items-center text-xs text-muted-foreground bg-slate-50 px-2 py-1 rounded">
              <Wifi className="w-3 h-3 mr-1" /> Wifi
            </div>
          )}
          {features.includes("parking") && (
            <div className="flex items-center text-xs text-muted-foreground bg-slate-50 px-2 py-1 rounded">
              <Car className="w-3 h-3 mr-1" /> Parkir
            </div>
          )}
          {features.includes("canteen") && (
            <div className="flex items-center text-xs text-muted-foreground bg-slate-50 px-2 py-1 rounded">
              <Utensils className="w-3 h-3 mr-1" /> Kantin
            </div>
          )}
        </div>
        
        <div className="flex items-baseline gap-1">
          <span className="text-primary font-bold text-lg">{price}</span>
          <span className="text-muted-foreground text-xs">/ jam</span>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button className="w-full bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900">
          Booking Sekarang
        </Button>
      </CardFooter>
    </Card>
  );
}