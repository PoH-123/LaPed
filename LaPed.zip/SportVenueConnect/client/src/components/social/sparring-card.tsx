import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Users } from "lucide-react";

interface SparringCardProps {
  teamName: string;
  sport: string;
  level: string;
  date: string;
  time: string;
  location: string;
  needed: number;
  image?: string;
}

export function SparringCard({
  teamName,
  sport,
  level,
  date,
  time,
  location,
  needed,
  image
}: SparringCardProps) {
  return (
    <div className="flex bg-white dark:bg-slate-900 border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all">
      {/* Left: Date/Time Column */}
      <div className="w-24 bg-primary/5 flex flex-col items-center justify-center p-4 border-r border-dashed">
        <span className="text-xs font-bold text-primary uppercase tracking-wider mb-1">{date.split(' ')[0]}</span>
        <span className="text-2xl font-bold text-slate-900">{date.split(' ')[1]}</span>
        <div className="mt-2 pt-2 border-t border-primary/20 w-full text-center">
          <span className="text-xs font-medium text-muted-foreground block">{time}</span>
        </div>
      </div>

      {/* Right: Content */}
      <div className="flex-1 p-4 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="capitalize bg-purple-50 text-purple-700 hover:bg-purple-100 border-purple-100">
                {sport}
              </Badge>
              <Badge variant="outline" className="border-orange-200 text-orange-700 bg-orange-50">
                {level}
              </Badge>
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <Users className="w-3 h-3 mr-1" /> Butuh {needed} orang
            </div>
          </div>
          
          <h3 className="font-heading font-bold text-lg mb-1">{teamName}</h3>
          
          <div className="flex items-center text-sm text-muted-foreground mb-3">
            <MapPin className="w-3 h-3 mr-1" /> {location}
          </div>
        </div>

        <div className="flex items-center justify-between mt-2">
          <div className="flex -space-x-2">
            {[1,2,3].map((i) => (
              <div key={i} className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center text-[10px] font-bold text-slate-500">
                U{i}
              </div>
            ))}
            <div className="w-8 h-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center text-[10px] font-medium text-slate-500">
              +2
            </div>
          </div>
          <Button size="sm" className="bg-primary text-white hover:bg-blue-600">
            Join Sparing
          </Button>
        </div>
      </div>
    </div>
  );
}