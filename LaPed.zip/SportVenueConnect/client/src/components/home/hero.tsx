import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  MapPin, 
  Calendar, 
  Dumbbell 
} from "lucide-react";
import { motion } from "framer-motion";
import heroImage from "@assets/generated_images/energetic_indoor_futsal_match_action_shot.png";

export function Hero() {
  return (
    <div className="relative w-full min-h-[600px] flex items-center justify-center overflow-hidden bg-slate-900">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Sports Action" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/40 via-slate-900/60 to-background" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto"
        >
          <h1 className="text-4xl md:text-6xl font-bold font-heading text-white mb-6 leading-tight">
            Temukan Lapangan & <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Lawan Tanding
            </span> Favoritmu
          </h1>
          <p className="text-lg text-gray-200 mb-10 max-w-2xl mx-auto">
            Booking lapangan futsal, badminton, basket, dan lainnya dengan mudah. 
            Cari teman sparring dan gabung komunitas olahraga di sekitarmu.
          </p>

          {/* Search Box */}
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/20 shadow-2xl max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="relative group">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-primary transition-colors" />
                <Input 
                  placeholder="Lokasi (mis. Jakarta Selatan)" 
                  className="pl-9 bg-white/90 border-0 h-12 text-slate-900 placeholder:text-slate-500 focus-visible:ring-0 focus-visible:bg-white transition-all"
                />
              </div>
              
              <div className="relative group">
                <Dumbbell className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-primary transition-colors" />
                <select className="w-full h-12 pl-9 pr-3 rounded-md bg-white/90 border-0 text-slate-900 text-sm focus:outline-none focus:bg-white transition-all appearance-none cursor-pointer">
                  <option value="">Pilih Olahraga</option>
                  <option value="futsal">Futsal</option>
                  <option value="badminton">Badminton</option>
                  <option value="basketball">Basket</option>
                  <option value="tennis">Tenis</option>
                </select>
              </div>

              <div className="relative group">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-primary transition-colors" />
                <Input 
                  type="date"
                  className="pl-9 bg-white/90 border-0 h-12 text-slate-900 placeholder:text-slate-500 focus-visible:ring-0 focus-visible:bg-white transition-all"
                />
              </div>

              <Button className="h-12 bg-brand-gradient border-0 font-semibold text-md hover:opacity-90 shadow-lg shadow-primary/25 transition-all">
                Cari Lapangan
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}