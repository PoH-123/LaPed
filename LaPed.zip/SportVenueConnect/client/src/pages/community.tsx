import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SparringCard } from "@/components/social/sparring-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Users, Trophy, Calendar } from "lucide-react";

export default function Community() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-6 pb-20">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-heading font-bold text-slate-900 dark:text-white">Komunitas</h1>
          <p className="text-muted-foreground">Temukan teman, gabung grup, dan ikuti event seru.</p>
        </div>

        <Tabs defaultValue="sparring" className="w-full">
          <TabsList className="w-full justify-start h-12 bg-transparent border-b rounded-none px-0 mb-8 gap-6">
            <TabsTrigger value="sparring" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3 text-base">
              Sparing Finder
            </TabsTrigger>
            <TabsTrigger value="groups" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3 text-base">
              Grup & Klub
            </TabsTrigger>
            <TabsTrigger value="events" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3 text-base">
              Event & Turnamen
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sparring" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <SparringCard 
                  key={i}
                  teamName={`Team Sparing #${i}`}
                  sport={i % 2 === 0 ? "Futsal" : "Badminton"}
                  level="Intermediate"
                  date="Sab 12"
                  time="19:00"
                  location="Arena Futsal Champions"
                  needed={2}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="groups">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="overflow-hidden hover:shadow-lg transition-all">
                  <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600"></div>
                  <div className="px-6 -mt-8">
                    <div className="w-16 h-16 rounded-2xl bg-white shadow-md flex items-center justify-center text-2xl font-bold text-primary border-4 border-white">
                      {i === 1 ? "⚽" : i === 2 ? "🏸" : "🏀"}
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <h3 className="font-heading font-bold text-xl">Komunitas Olahraga {i}</h3>
                    <p className="text-sm text-muted-foreground">Jakarta Selatan • 1.2k Anggota</p>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full">Gabung Grup</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="events">
            <div className="text-center py-20">
              <Trophy className="w-16 h-16 mx-auto text-slate-300 mb-4" />
              <h3 className="text-xl font-bold text-slate-900">Belum ada event terdekat</h3>
              <p className="text-muted-foreground">Coba cari di lokasi lain atau buat event kamu sendiri.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}