import { useState } from "react";
import { VenueCard } from "@/components/venue/venue-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, SlidersHorizontal, Map as MapIcon, List } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import venueFutsal from "@assets/generated_images/modern_indoor_futsal_court_empty.png";
import venueBadminton from "@assets/generated_images/indoor_badminton_court_empty.png";
import venueBasketball from "@assets/generated_images/urban_basketball_court_at_twilight.png";

export default function Explore() {
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-6 pb-20">
      <div className="container mx-auto px-4">
        
        {/* Header Filter */}
        <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-heading font-bold text-slate-900 dark:text-white">Jelajah Lapangan</h1>
            <p className="text-muted-foreground">Temukan venue olahraga terbaik di sekitarmu</p>
          </div>
          
          <div className="flex items-center bg-white dark:bg-slate-900 p-1 rounded-lg border shadow-sm">
            <Button 
              variant={viewMode === 'list' ? 'secondary' : 'ghost'} 
              size="sm" 
              onClick={() => setViewMode('list')}
              className="gap-2"
            >
              <List className="w-4 h-4" /> List
            </Button>
            <Button 
              variant={viewMode === 'map' ? 'secondary' : 'ghost'} 
              size="sm" 
              onClick={() => setViewMode('map')}
              className="gap-2"
            >
              <MapIcon className="w-4 h-4" /> Peta
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border shadow-sm mb-8 sticky top-20 z-30">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Cari nama lapangan atau daerah..." className="pl-9 bg-slate-50 border-slate-200" />
            </div>
            <Button variant="outline" className="gap-2 border-slate-200">
              <SlidersHorizontal className="w-4 h-4" /> Filter
            </Button>
          </div>
          
          <div className="flex gap-2 mt-4 overflow-x-auto pb-1 scrollbar-hide">
            {['Semua', 'Futsal', 'Badminton', 'Basket', 'Tenis', 'Mini Soccer'].map((cat, i) => (
              <Button 
                key={cat} 
                variant={i === 0 ? "default" : "outline"} 
                size="sm" 
                className="rounded-full"
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((item, i) => (
            <VenueCard 
              key={i}
              title={i % 2 === 0 ? "Arena Futsal Champions" : "GOR Badminton Sejahtera"}
              location="Jakarta Selatan"
              price={i % 2 === 0 ? "Rp 150.000" : "Rp 80.000"}
              rating={4.8}
              reviews={120}
              image={i % 2 === 0 ? venueFutsal : venueBadminton}
              type={i % 2 === 0 ? "Futsal" : "Badminton"}
              features={["wifi", "parking"]}
            />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button variant="outline" size="lg">Muat Lebih Banyak</Button>
        </div>
      </div>
    </div>
  );
}